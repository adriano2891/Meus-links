// Meus Links - Background Service Worker (Manifest V3)

chrome.runtime.onInstalled.addListener((details) => {
  console.log('[Meus Links] Extensão instalada com sucesso! Razão:', details.reason);
  // Set default server URL if not already configured
  chrome.storage.local.get(['serverUrl'], (res) => {
    if (!res.serverUrl) {
      chrome.storage.local.set({ serverUrl: 'https://ais-dev-m7nv3mtsexqu3z4xsx5pxl-372689701151.us-east1.run.app' });
    }
  });
});

// Listener for keyboard command
chrome.commands.onCommand.addListener((command) => {
  if (command === '_execute_action') {
    console.log('[Meus Links] Comando de atalho acionado.');
  }
});
