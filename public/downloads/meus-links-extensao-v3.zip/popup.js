// Meus Links - Popup Script (Manifest V3)

const DEFAULT_SERVER_URL = "https://ais-dev-m7nv3mtsexqu3z4xsx5pxl-372689701151.us-east1.run.app";

// DOM Elements
const loadingView = document.getElementById("loadingView");
const loginView = document.getElementById("loginView");
const saveView = document.getElementById("saveView");
const successView = document.getElementById("successView");

const userBadgeArea = document.getElementById("userBadgeArea");
const headerUserEmail = document.getElementById("headerUserEmail");
const logoutBtn = document.getElementById("logoutBtn");
const headerStatus = document.getElementById("headerStatus");

// Login Elements
const loginForm = document.getElementById("loginForm");
const loginEmail = document.getElementById("loginEmail");
const loginPassword = document.getElementById("loginPassword");
const loginError = document.getElementById("loginError");
const submitLoginBtn = document.getElementById("submitLoginBtn");
const toggleServerBtn = document.getElementById("toggleServerBtn");
const serverConfigBox = document.getElementById("serverConfigBox");
const serverUrlInput = document.getElementById("serverUrlInput");

// Save Elements
const saveForm = document.getElementById("saveForm");
const linkTitle = document.getElementById("linkTitle");
const linkUrl = document.getElementById("linkUrl");
const categorySelect = document.getElementById("categorySelect");
const subcategorySelect = document.getElementById("subcategorySelect");
const linkTags = document.getElementById("linkTags");
const isFavorite = document.getElementById("isFavorite");
const isReadLater = document.getElementById("isReadLater");
const saveLinkBtn = document.getElementById("saveLinkBtn");
const saveError = document.getElementById("saveError");
const faviconArea = document.getElementById("faviconArea");
const categoryHint = document.getElementById("categoryHint");

// Success Elements
const summaryTitle = document.getElementById("summaryTitle");
const summaryUrl = document.getElementById("summaryUrl");
const summaryCategory = document.getElementById("summaryCategory");
const openAppBtn = document.getElementById("openAppBtn");
const saveAnotherBtn = document.getElementById("saveAnotherBtn");

// State
let appState = {
  authToken: null,
  user: null,
  serverUrl: DEFAULT_SERVER_URL,
  categories: [],
  subcategories: []
};

// Polyfill chrome.storage for local browser testing if needed
const storage = {
  get: (keys, cb) => {
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get(keys, cb);
    } else {
      const res = {};
      keys.forEach((k) => {
        try {
          const val = localStorage.getItem("meuslinks_" + k);
          if (val) res[k] = JSON.parse(val);
        } catch {}
      });
      cb(res);
    }
  },
  set: (items, cb) => {
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
      chrome.storage.local.set(items, cb);
    } else {
      Object.keys(items).forEach((k) => {
        try {
          localStorage.setItem("meuslinks_" + k, JSON.stringify(items[k]));
        } catch {}
      });
      if (cb) cb();
    }
  },
  remove: (keys, cb) => {
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
      chrome.storage.local.remove(keys, cb);
    } else {
      keys.forEach((k) => localStorage.removeItem("meuslinks_" + k));
      if (cb) cb();
    }
  }
};

// Switch Views Helper
function showView(viewId) {
  loadingView.style.display = "none";
  loginView.style.display = "none";
  saveView.style.display = "none";
  successView.style.display = "none";

  if (viewId === "login") {
    loginView.style.display = "block";
    userBadgeArea.style.display = "none";
    headerStatus.textContent = "Desconectado";
    headerStatus.style.color = "var(--text-muted)";
  } else if (viewId === "save") {
    saveView.style.display = "block";
    userBadgeArea.style.display = "flex";
    headerUserEmail.textContent = appState.user?.email || "Conectado";
    headerStatus.textContent = "Pronto para salvar";
    headerStatus.style.color = "var(--success-color)";
  } else if (viewId === "success") {
    successView.style.display = "block";
    userBadgeArea.style.display = "flex";
    headerStatus.textContent = "Salvo!";
    headerStatus.style.color = "var(--success-color)";
  } else {
    loadingView.style.display = "block";
  }
}

// 1. Initialize
document.addEventListener("DOMContentLoaded", async () => {
  showView("loading");

  // Read saved settings from storage
  storage.get(["authToken", "user", "serverUrl"], async (data) => {
    if (data.serverUrl) {
      appState.serverUrl = data.serverUrl.replace(/\/+$/, "");
    }
    serverUrlInput.value = appState.serverUrl;

    // Detect active tab info
    await captureActiveTab();

    if (data.authToken && data.user) {
      appState.authToken = data.authToken;
      appState.user = data.user;
      await loadCategoriesAndSetupSaveView();
    } else {
      showView("login");
    }
  });

  // Toggle server URL configuration
  toggleServerBtn.addEventListener("click", () => {
    const isHidden = serverConfigBox.style.display === "none";
    serverConfigBox.style.display = isHidden ? "flex" : "none";
  });

  serverUrlInput.addEventListener("change", (e) => {
    let clean = (e.target.value || "").trim().replace(/\/+$/, "");
    if (!clean) clean = DEFAULT_SERVER_URL;
    appState.serverUrl = clean;
    storage.set({ serverUrl: clean });
  });

  // Handle Login
  loginForm.addEventListener("submit", handleLogin);

  // Handle Save
  saveForm.addEventListener("submit", handleSaveLink);

  // Handle Logout
  logoutBtn.addEventListener("click", handleLogout);

  // Handle Category Change -> Update Subcategories
  categorySelect.addEventListener("change", handleCategoryChange);

  // Success view actions
  openAppBtn.addEventListener("click", () => {
    const targetUrl = appState.serverUrl || DEFAULT_SERVER_URL;
    if (typeof chrome !== "undefined" && chrome.tabs && chrome.tabs.create) {
      chrome.tabs.create({ url: targetUrl });
    } else {
      window.open(targetUrl, "_blank");
    }
  });

  saveAnotherBtn.addEventListener("click", () => {
    showView("save");
  });
});

// Capture active tab
async function captureActiveTab() {
  try {
    if (typeof chrome !== "undefined" && chrome.tabs && chrome.tabs.query) {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tabs && tabs[0]) {
        const tab = tabs[0];
        linkUrl.value = tab.url || "";
        linkTitle.value = tab.title || "";
        if (tab.favIconUrl) {
          faviconArea.innerHTML = `<img src="${tab.favIconUrl}" alt="" width="14" height="14" style="border-radius:2px; vertical-align:middle;">`;
        }
      }
    } else {
      // Fallback for direct browser testing
      linkUrl.value = window.location.href;
      linkTitle.value = document.title;
    }
  } catch (err) {
    console.warn("Could not query active tab:", err);
  }
}

// Login Handler
async function handleLogin(e) {
  e.preventDefault();
  loginError.style.display = "none";
  setButtonLoading(submitLoginBtn, true, "Verificando...");

  const email = loginEmail.value.trim();
  const password = loginPassword.value;

  try {
    const resp = await fetch(`${appState.serverUrl}/api/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password })
    });

    const data = await resp.json();

    if (!resp.ok || !data.token) {
      throw new Error(data.error || "E-mail ou senha inválidos.");
    }

    // Success login
    appState.authToken = data.token;
    appState.user = data.user;

    storage.set({
      authToken: data.token,
      user: data.user,
      serverUrl: appState.serverUrl
    });

    await loadCategoriesAndSetupSaveView();
  } catch (err) {
    loginError.textContent = err.message || "Falha ao conectar com o servidor do App.";
    loginError.style.display = "block";
  } finally {
    setButtonLoading(submitLoginBtn, false, "Entrar na Conta");
  }
}

// Load Categories & Subcategories
async function loadCategoriesAndSetupSaveView() {
  showView("loading");
  saveError.style.display = "none";

  try {
    const authHeader = { Authorization: `Bearer ${appState.authToken}` };

    const [catRes, subRes] = await Promise.all([
      fetch(`${appState.serverUrl}/api/categories`, { headers: authHeader }),
      fetch(`${appState.serverUrl}/api/subcategories`, { headers: authHeader })
    ]);

    if (!catRes.ok) {
      if (catRes.status === 401) {
        handleLogout();
        throw new Error("Sua sessão expirou. Por favor, entre novamente.");
      }
      throw new Error("Erro ao carregar categorias do App.");
    }

    const categories = await catRes.json();
    const subcategories = subRes.ok ? await subRes.json() : [];

    appState.categories = Array.isArray(categories) ? categories : [];
    appState.subcategories = Array.isArray(subcategories) ? subcategories : [];

    // Populate Category select
    categorySelect.innerHTML = `<option value="">-- Selecione uma categoria (obrigatório) --</option>`;
    appState.categories.forEach((cat) => {
      const opt = document.createElement("option");
      opt.value = cat.id;
      opt.textContent = `📁 ${cat.name}`;
      categorySelect.appendChild(opt);
    });

    // Reset subcategories select
    subcategorySelect.innerHTML = `<option value="">Nenhuma (salvar na categoria geral)</option>`;

    // If there is only 1 category, auto-select it for convenience
    if (appState.categories.length === 1) {
      categorySelect.value = appState.categories[0].id;
      handleCategoryChange();
    }

    showView("save");
  } catch (err) {
    showView("login");
    loginError.textContent = err.message;
    loginError.style.display = "block";
  }
}

// Category Change Handler -> Update Subcategories dropdown
function handleCategoryChange() {
  const selectedCatId = categorySelect.value;
  subcategorySelect.innerHTML = `<option value="">Nenhuma (salvar na categoria geral)</option>`;

  if (!selectedCatId) {
    categoryHint.textContent = "A seleção de categoria é obrigatória para salvar.";
    categoryHint.style.color = "#ef4444";
    return;
  }

  categoryHint.textContent = "Categoria selecionada com sucesso.";
  categoryHint.style.color = "var(--success-color)";

  // Filter subcategories for this category
  const filtered = appState.subcategories.filter((s) => s.categoryId === selectedCatId);
  if (filtered.length > 0) {
    filtered.forEach((sub) => {
      const opt = document.createElement("option");
      opt.value = sub.id;
      opt.textContent = `↳ ${sub.name}`;
      subcategorySelect.appendChild(opt);
    });
    document.getElementById("subcategoryGroup").style.display = "flex";
  } else {
    document.getElementById("subcategoryGroup").style.display = "flex";
  }
}

// Save Link Handler
async function handleSaveLink(e) {
  e.preventDefault();
  saveError.style.display = "none";

  const url = linkUrl.value.trim();
  const title = linkTitle.value.trim();
  const categoryId = categorySelect.value;
  const subcategoryId = subcategorySelect.value || undefined;
  const rawTags = linkTags.value;

  if (!url) {
    showSaveError("Por favor, preencha o endereço (URL).");
    return;
  }

  // MANDATORY CATEGORY VALIDATION
  if (!categoryId) {
    categorySelect.focus();
    showSaveError("A categoria é obrigatória! Selecione uma categoria antes de salvar.");
    categoryHint.style.color = "#ef4444";
    return;
  }

  const tags = rawTags
    .split(",")
    .map((t) => t.trim())
    .filter(Boolean);

  if (!tags.includes("Extensão")) {
    tags.unshift("Extensão");
  }

  setButtonLoading(saveLinkBtn, true, "Salvando no App...");

  try {
    const payload = {
      url,
      title: title || url,
      categoryId,
      subcategoryId,
      tags,
      isFavorite: isFavorite.checked,
      isReadLater: isReadLater.checked,
      source: "extension"
    };

    const resp = await fetch(`${appState.serverUrl}/api/extension/quick-save`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${appState.authToken}`,
        "x-api-token": appState.authToken
      },
      body: JSON.stringify(payload)
    });

    const result = await resp.json();

    if (!resp.ok) {
      throw new Error(result.error || "Erro ao salvar o link no App.");
    }

    // Success State
    const chosenCat = appState.categories.find((c) => c.id === categoryId);
    summaryTitle.textContent = title || url;
    summaryUrl.textContent = url;
    summaryCategory.textContent = chosenCat ? chosenCat.name : "Categoria selecionada";

    showView("success");
  } catch (err) {
    showSaveError(err.message || "Erro de conexão ao salvar link.");
  } finally {
    setButtonLoading(saveLinkBtn, false, "SALVAR NO APP");
  }
}

function showSaveError(msg) {
  saveError.textContent = msg;
  saveError.style.display = "block";
}

// Logout Handler
function handleLogout() {
  appState.authToken = null;
  appState.user = null;
  storage.remove(["authToken", "user"], () => {
    loginPassword.value = "";
    showView("login");
  });
}

// Helper: Button Loading state
function setButtonLoading(btn, isLoading, text) {
  const btnText = btn.querySelector(".btn-text");
  const spinner = btn.querySelector(".btn-spinner");
  const icon = btn.querySelector(".btn-icon");

  btn.disabled = isLoading;
  if (btnText) btnText.textContent = text;
  if (spinner) spinner.style.display = isLoading ? "block" : "none";
  if (icon) icon.style.display = isLoading ? "none" : "block";
}
